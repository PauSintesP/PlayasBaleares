package com.example.cercahabitatge;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referenciar el campo de texto y los botones
        EditText etMunicipi = findViewById(R.id.etMunicipi);
        Button btnCerca = findViewById(R.id.btnCerca);
        Button btnExit = findViewById(R.id.btnExit);

        // Configurar el botón "Cerca" para navegar a Activity2
        btnCerca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener el texto del municipio
                String municipi = etMunicipi.getText().toString();

                // Crear el intent para pasar a Activity2
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                // Pasar el nombre del municipio a la siguiente activity
                intent.putExtra("municipi", municipi);
                startActivity(intent);
            }
        });

        // Configurar el botón "Exit" para cerrar la aplicación
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cerrar la aplicación
                finishAffinity();
            }
        });
    }
}
