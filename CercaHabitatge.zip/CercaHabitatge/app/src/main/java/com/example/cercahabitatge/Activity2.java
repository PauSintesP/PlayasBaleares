package com.example.cercahabitatge;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        // Obtener el nombre del municipio del intent
        TextView tvMunicipiName = findViewById(R.id.tvMunicipiName);
        String municipi = getIntent().getStringExtra("municipi");
        tvMunicipiName.setText("Municipi: " + municipi);

        // Botón Home: Volver a MainActivity
        Button btnHome = findViewById(R.id.btnHome);
        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(Activity2.this, MainActivity.class);
            startActivity(intent);
        });

        // Botón Detall: Ir a Activity3
        Button btnDetall = findViewById(R.id.btnDetall);
        btnDetall.setOnClickListener(v -> {
            Intent intent = new Intent(Activity2.this, Activity3.class);
            intent.putExtra("municipi", municipi); // Pasar el municipio a Activity3
            startActivity(intent);
        });

        // Botón Exit: Cerrar la aplicación
        Button btnExit = findViewById(R.id.btnExit2);
        btnExit.setOnClickListener(v -> finishAffinity());
    }
}
