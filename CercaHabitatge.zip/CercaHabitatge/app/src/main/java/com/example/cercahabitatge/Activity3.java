package com.example.cercahabitatge;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        // Obtener el nombre del municipio del intent
        TextView tvMunicipiNameDetail = findViewById(R.id.tvMunicipiNameDetail);
        String municipi = getIntent().getStringExtra("municipi");
        tvMunicipiNameDetail.setText("Municipi: " + municipi);

        // Botón List: Regresa a Activity2 (Lista)
        Button btnList = findViewById(R.id.btnList);
        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity3.this, Activity2.class);
                intent.putExtra("municipi", municipi); // Pasar el municipio de vuelta a Activity2
                startActivity(intent);
            }
        });

        // Botón Contactar: Muestra un mensaje "Contacte OK"
        Button btnContactar = findViewById(R.id.btnContactar);
        btnContactar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mostrar un Toast con el mensaje "Contacte OK"
                Toast.makeText(Activity3.this, "Contacte OK", Toast.LENGTH_SHORT).show();
            }
        });

        // Botón Exit: Cierra la aplicación
        Button btnExit3 = findViewById(R.id.btnExit3);
        btnExit3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity(); // Cerrar la aplicación
            }
        });
    }
}
